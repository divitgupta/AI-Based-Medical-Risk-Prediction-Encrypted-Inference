module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>> {
    %cst = arith.constant dense<[[-2], [43], [30], [-12], [58], [121], [-26], [73], [127], [50], [-49], [-98], [27], [-13], [9], [17], [60], [-54], [-128], [56], [72], [30], [-24], [-27], [74]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<16>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<16>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %c8_i5 = arith.constant 8 : i5
    %from_elements = tensor.from_elements %c8_i5 : tensor<1xi5>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<16>>, tensor<1xi5>) -> tensor<1x1x!FHE.esint<16>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %cst_0 = arith.constant dense<-9878> : tensor<1x1xi16>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1xi16>) -> tensor<1x1x!FHE.esint<16>>
    return %4 : tensor<1x1x!FHE.esint<16>>
  }
}