module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>> {
    %cst = arith.constant dense<[[4], [48], [38], [-33], [76], [127], [20], [98], [121], [-10], [-25], [-6], [37], [-4], [27], [-16], [78], [-1], [-128], [54], [108], [47], [-6], [-25], [90]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<17>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<17>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>>
    %c20_i6 = arith.constant 20 : i6
    %from_elements = tensor.from_elements %c20_i6 : tensor<1xi6>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<17>>, tensor<1xi6>) -> tensor<1x1x!FHE.esint<17>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<17>>, tensor<1x1x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>>
    %cst_0 = arith.constant dense<-12454> : tensor<1x1xi16>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<17>>, tensor<1x1xi16>) -> tensor<1x1x!FHE.esint<17>>
    return %4 : tensor<1x1x!FHE.esint<17>>
  }
}