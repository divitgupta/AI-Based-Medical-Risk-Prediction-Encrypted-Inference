module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>> {
    %cst = arith.constant dense<[[23], [48], [40], [-90], [109], [105], [16], [88], [127], [-16], [-51], [-19], [30], [-13], [13], [8], [54], [-32], [-128], [58], [70], [40], [13], [-105], [122]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<17>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<17>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>>
    %c10_i5 = arith.constant 10 : i5
    %from_elements = tensor.from_elements %c10_i5 : tensor<1xi5>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<17>>, tensor<1xi5>) -> tensor<1x1x!FHE.esint<17>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<17>>, tensor<1x1x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>>
    %cst_0 = arith.constant dense<-10513> : tensor<1x1xi16>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<17>>, tensor<1x1xi16>) -> tensor<1x1x!FHE.esint<17>>
    return %4 : tensor<1x1x!FHE.esint<17>>
  }
}