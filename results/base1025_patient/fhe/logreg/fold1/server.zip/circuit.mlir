module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>> {
    %cst = arith.constant dense<[[3], [46], [25], [-54], [69], [127], [7], [46], [99], [11], [-55], [-20], [27], [-23], [22], [24], [41], [-39], [-128], [49], [86], [28], [-23], [-58], [108]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<16>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<16>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %c9_i5 = arith.constant 9 : i5
    %from_elements = tensor.from_elements %c9_i5 : tensor<1xi5>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<16>>, tensor<1xi5>) -> tensor<1x1x!FHE.esint<16>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %cst_0 = arith.constant dense<-7976> : tensor<1x1xi15>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1xi15>) -> tensor<1x1x!FHE.esint<16>>
    return %4 : tensor<1x1x!FHE.esint<16>>
  }
}