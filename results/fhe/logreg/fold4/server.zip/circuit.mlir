module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>> {
    %cst = arith.constant dense<[[30], [51], [37], [-47], [96], [101], [32], [82], [127], [3], [-49], [-13], [35], [-3], [19], [11], [82], [-42], [-128], [62], [82], [52], [15], [-63], [99]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<17>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<17>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>>
    %c17_i6 = arith.constant 17 : i6
    %from_elements = tensor.from_elements %c17_i6 : tensor<1xi6>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<17>>, tensor<1xi6>) -> tensor<1x1x!FHE.esint<17>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<17>>, tensor<1x1x!FHE.esint<17>>) -> tensor<1x1x!FHE.esint<17>>
    %cst_0 = arith.constant dense<-10858> : tensor<1x1xi16>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<17>>, tensor<1x1xi16>) -> tensor<1x1x!FHE.esint<17>>
    return %4 : tensor<1x1x!FHE.esint<17>>
  }
}