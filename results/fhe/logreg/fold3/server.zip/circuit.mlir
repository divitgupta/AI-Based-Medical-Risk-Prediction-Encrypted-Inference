module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>> {
    %cst = arith.constant dense<[[-1], [37], [23], [-74], [78], [90], [-12], [83], [127], [-20], [-68], [-39], [37], [-40], [3], [-12], [39], [-26], [-128], [50], [60], [18], [-6], [-93], [99]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<16>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<16>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %c0_i2 = arith.constant 0 : i2
    %from_elements = tensor.from_elements %c0_i2 : tensor<1xi2>
    %2 = "FHELinalg.to_unsigned"(%1) : (tensor<1x1x!FHE.esint<16>>) -> tensor<1x1x!FHE.eint<16>>
    %3 = "FHELinalg.mul_eint_int"(%2, %from_elements) : (tensor<1x1x!FHE.eint<16>>, tensor<1xi2>) -> tensor<1x1x!FHE.eint<16>>
    %4 = "FHELinalg.to_signed"(%3) : (tensor<1x1x!FHE.eint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %5 = "FHELinalg.sub_eint"(%0, %4) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %cst_0 = arith.constant dense<-5906> : tensor<1x1xi15>
    %6 = "FHELinalg.add_eint_int"(%5, %cst_0) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1xi15>) -> tensor<1x1x!FHE.esint<16>>
    return %6 : tensor<1x1x!FHE.esint<16>>
  }
}