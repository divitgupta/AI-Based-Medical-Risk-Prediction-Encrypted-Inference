module {
  func.func @inference_to_compile(%arg0: tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>> {
    %cst = arith.constant dense<[[2], [10], [2], [-61], [88], [72], [-19], [90], [127], [-11], [-66], [-42], [21], [-19], [4], [2], [64], [-60], [-128], [50], [65], [21], [-4], [-99], [109]]> : tensor<25x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x25x!FHE.esint<16>>, tensor<25x1xi9>) -> tensor<1x1x!FHE.esint<16>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x25x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %c2_i3 = arith.constant 2 : i3
    %from_elements = tensor.from_elements %c2_i3 : tensor<1xi3>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<16>>, tensor<1xi3>) -> tensor<1x1x!FHE.esint<16>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %cst_0 = arith.constant dense<-7874> : tensor<1x1xi15>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1xi15>) -> tensor<1x1x!FHE.esint<16>>
    return %4 : tensor<1x1x!FHE.esint<16>>
  }
}