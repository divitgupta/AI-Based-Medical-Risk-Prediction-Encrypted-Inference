module {
  func.func @inference_to_compile(%arg0: tensor<1x30x!FHE.esint<19>>) -> tensor<1x1x!FHE.eint<19>> {
    %cst = arith.constant dense<[[-29], [-34], [-24], [-32], [12], [127], [-41], [-54], [18], [67], [-105], [73], [-33], [-84], [19], [127], [62], [-19], [88], [99], [-87], [-128], [-62], [-87], [-60], [47], [-70], [-88], [-86], [15]]> : tensor<30x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x30x!FHE.esint<19>>, tensor<30x1xi9>) -> tensor<1x1x!FHE.esint<19>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x30x!FHE.esint<19>>) -> tensor<1x1x!FHE.esint<19>>
    %c40_i7 = arith.constant 40 : i7
    %from_elements = tensor.from_elements %c40_i7 : tensor<1xi7>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<19>>, tensor<1xi7>) -> tensor<1x1x!FHE.esint<19>>
    %3 = "FHELinalg.to_unsigned"(%0) : (tensor<1x1x!FHE.esint<19>>) -> tensor<1x1x!FHE.eint<19>>
    %4 = "FHELinalg.to_unsigned"(%2) : (tensor<1x1x!FHE.esint<19>>) -> tensor<1x1x!FHE.eint<19>>
    %5 = "FHELinalg.sub_eint"(%3, %4) : (tensor<1x1x!FHE.eint<19>>, tensor<1x1x!FHE.eint<19>>) -> tensor<1x1x!FHE.eint<19>>
    %cst_0 = arith.constant dense<126238> : tensor<1x1xi18>
    %6 = "FHELinalg.add_eint_int"(%5, %cst_0) : (tensor<1x1x!FHE.eint<19>>, tensor<1x1xi18>) -> tensor<1x1x!FHE.eint<19>>
    return %6 : tensor<1x1x!FHE.eint<19>>
  }
}