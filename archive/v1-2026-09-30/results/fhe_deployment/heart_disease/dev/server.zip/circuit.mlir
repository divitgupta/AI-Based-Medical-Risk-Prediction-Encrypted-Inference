module {
  func.func @inference_to_compile(%arg0: tensor<1x30x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>> {
    %cst = arith.constant dense<[[29], [-20], [-52], [43], [-41], [79], [-59], [-128], [-5], [84], [84], [6], [14], [-5], [39], [-7], [57], [-37], [5], [-41], [64], [127], [-57], [-90], [-9], [72], [12], [21], [92], [-90]]> : tensor<30x1xi9>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x30x!FHE.esint<16>>, tensor<30x1xi9>) -> tensor<1x1x!FHE.esint<16>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x30x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %c8_i5 = arith.constant 8 : i5
    %from_elements = tensor.from_elements %c8_i5 : tensor<1xi5>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<16>>, tensor<1xi5>) -> tensor<1x1x!FHE.esint<16>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1x!FHE.esint<16>>) -> tensor<1x1x!FHE.esint<16>>
    %cst_0 = arith.constant dense<1747> : tensor<1x1xi12>
    %4 = "FHELinalg.add_eint_int"(%3, %cst_0) : (tensor<1x1x!FHE.esint<16>>, tensor<1x1xi12>) -> tensor<1x1x!FHE.esint<16>>
    return %4 : tensor<1x1x!FHE.esint<16>>
  }
}